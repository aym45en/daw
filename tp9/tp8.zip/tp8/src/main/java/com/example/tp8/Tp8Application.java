package com.example.tp8;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Tp8Application {

	public static void main(String[] args) {
		SpringApplication.run(Tp8Application.class, args);
	}

}
